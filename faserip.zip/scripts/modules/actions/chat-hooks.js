// chat-hooks.js v1.5.6 - 2026-02-21
// v1.5.6: Fix Apply Damage and Resolve Slam buttons not working in semi mode - canDriveAutoSaves bail was blocking all button handler registration for non-owners
// v1.5.5: Fix reload handler - resolve synthetic token actors via canvas.tokens
// v1.5.4: Add reload button handler for out-of-ammo chat card
// v1.5.3: Fix dodge reapply - add movementMult and selfPenaltyCS to AE changes (was missing same as defense-action.js)
// v1.5.2: Fix createEvadingEffect - pass evadeSuccessful/autoHit to applyEvade for proper flag tracking
// v1.5.1: Wire dodge CS penalty to Active Effect changes (defenseShift/defenseShiftRanged)
// v1.5.0: Add grapple-back handler for Reverse escape result
// v1.4.0: Add hold-damage handler for Full Hold grappling damage
// v1.3.0: Add detailed logging for escape effect removal debugging
// v1.2.0: Fix escape karma default unchecked, add grappled effect removal on successful escape
// v1.1.0: Add kill-save handler (conscious dying), update death-save to pass fromZeroHealth
// v1.0.4: Add apply-collision-damage handler that applies directly to UUID
// v1.0.3: Add stopImmediatePropagation to collision handlers to prevent duplicate dialogs
// v1.0.2: Add .calculate-slam-collision handler for slam result collision buttons (both standalone and collapsible)
// scripts/modules/actions/chat-hooks.js
import { ActionDispatcher } from "./action-dispatcher.js";
import { resolveCombatMode } from "./action-dispatcher.js";

import { openBreakingFeatDialog } from "./breaking-feat.js";
import { openGrabbingBreakDialog } from "./grabbing-break.js";
import { openCollisionDamageDialog } from "./collision-damage.js";
import { 
  shiftRank, 
  rollWithKarmaAndHistory, 
  buildResultGrid, 
  bannerColors, 
  effectsFor,
  applyDamageToTargets,
  applyDamageToActorUuid,
  getBodyArmorValues,
  debugLog
} from "./action-utils.js";
import { startAura, stopAura, isAuraMaintained } from "./nullify.js";
import { rollUniversalTable } from "../dice/universal-table.js";
import { generateKarmaControlsHTML, setupKarmaControlHandlers, extractKarmaFromDialog } from "../dice/dice-roller.js";
import * as Effects from "../effects/effect-engine.js";

/**
 * Handle escape check from chat card button
 * The escaping character is the current user's character or selected token
 */
async function handleEscapeCheck({ defenderUuid, defenderName, defenderRank }) {
  // The "defender" in this context is the person holding - we need the escaping character
  // which should be the current user's controlled token or character
  let escapingActor = null;
  
  // Try selected token first
  const controlled = canvas.tokens?.controlled?.[0];
  if (controlled?.actor) {
    escapingActor = controlled.actor;
  }
  
  // Fall back to user's character
  if (!escapingActor) {
    escapingActor = game.user?.character;
  }
  
  if (!escapingActor) {
    ui.notifications.warn("Select your token or set a character to attempt escape.");
    return;
  }
  
  // Call the escaping action with prefill data about the holder
  await ActionDispatcher.roll("escaping", {
    actor: escapingActor,
    opts: {
      prefill: {
        opponentName: defenderName || "",
        opponentStr: defenderRank || ""
      }
    }
  });
}

export function installActionChatHandlers() {
  // idempotent guard
  game.msh ??= {};
  if (game.msh.chatHooksInstalled) return;
  game.msh.chatHooksInstalled = true;

  // Helper to safely set flags only if user has permission
  async function safeSetFlag(message, scope, key, value) {
    try {
      // Check if user can modify this message
      if (!message.isOwner && !game.user.isGM) {
        debugLog(`Skipping flag set (no permission): ${key}`, { msgId: message.id, user: game.user.name });
        return false;
      }
      await message.setFlag(scope, key, value);
      return true;
    } catch (err) {
      console.warn(`Failed to set flag ${key} on message ${message.id}:`, err.message);
      return false;
    }
  }

  // SINGLE combined hook for all chat interactions
  Hooks.on("renderChatMessageHTML", async (message, htmlEl /* HTMLElement */, data) => {
    const html  = $(htmlEl);
    const SCOPE = game.system?.id || "msh-faserip";

    // --- NEW: Full-Auto damage application (idempotent)
    try {
      const flags      = message?.flags?.[SCOPE] ?? {};
      const shouldAuto = flags?.autoApply === true;
      const already    = flags?.autoApplied === true;
      const results    = flags?.results;

      if (shouldAuto && !already && Array.isArray(results) && results.length) {
        debugLog("Auto-applying damage", { msgId: message.id, targets: results.length });
        await applyDamageToTargets(results, { messageId: message.id });
        await safeSetFlag(message, SCOPE, "autoApplied", true); // guard against re-renders
      }
    } catch (err) {
      console.error("Auto-apply failed:", err);
    }

    // Bail if already auto-processed (prevents double-fire on rerender/notify)
    const alreadyHandled = await message.getFlag(SCOPE, "autoSaveHandled");

    // Only a user who can edit this message should drive auto-save logic.
    const canDriveAutoSaves = message.isOwner || game.user.isGM;

    // Auto-save logic block — only runs for message owner/GM, only once per message
    if (canDriveAutoSaves && !alreadyHandled) {

    let firedAnyCheck = false; // <— track if we actually ran something

   // --- NEW: Full-Auto auto-rolling of saves (Stun/Slam/Kill/Nullify/Death) ---
    try {
      const alreadyChecks = message?.flags?.[SCOPE]?.autoChecksDone === true;
      if (!alreadyChecks) {
        const didSet = await safeSetFlag(message, SCOPE, "autoChecksDone", true);
        if (!didSet) {
          if (game.settings.get("msh-faserip", "debugMode")) {
            console.log("FASERIP | autoChecksDone not set - skipping auto-saves", {
              msgId: message.id,
              user: game.user.name
            });
          }
          // Skip auto-saves but fall through to button handler registration
        }
        if (didSet) {

        // Derive an "owner" actor (attacker or speaker)
        let ownerActor = null;
        try {
          const attackerUuid = message?.flags?.[SCOPE]?.attackerUuid || message?.speaker?.actor;
          if (attackerUuid) {
            const doc = await fromUuid(attackerUuid);
            ownerActor = doc?.actor ?? doc ?? null;
          }
        } catch (_){}
        ownerActor = ownerActor ?? game.actors?.get(message.speaker?.actor) ?? game.user?.character ?? null;

        const mode = resolveCombatMode(ownerActor);
        if (mode === "full") {
          const chips     = html.find('a.faserip-chip[data-check]');
          const forceBtns = html.find('[data-action="force-save"], [data-action="force-save-nullify"]');
          const deathBtns = html.find('[data-action="death-save"]');

          // Track which (checkType, defender) pairs we've already auto-run for this message
          const autoSaveDefenderKeys = new Set();

          // Per-chip auto run (Stun/Slam/Kill). Chips from attacks include per-target prefill.
          // Auto-run Stun/Slam/Kill per defender in Full mode
          for (const el of chips.toArray()) {
            const checkType  = el.dataset.check;                // "stun"|"slam"|"kill"|"escape"
            if (checkType === "escape") continue;               // not a save

            const attackForm = el.dataset.attackForm || "blunt";

            // Resolve defender (preferred in this order)
            let saveActor = null;
            const saveUuid = el.dataset.targetUuid
                          || el.dataset.defenderUuid
                          || (el.dataset.prefill ? (JSON.parse(el.dataset.prefill.replaceAll("&apos;","'")).targetUuid || "") : "")
                          || "";

            if (saveUuid) {
              try {
                const doc = await fromUuid(saveUuid);
                saveActor = doc?.actor ?? doc ?? null;
              } catch (_){}
            }
            if (!saveActor && game.user?.targets?.size === 1) {
              saveActor = game.user.targets.first()?.actor ?? null;
            }
            if (!saveActor) continue;

            // Skip stun/slam if target is at 0 HP - death save handles unconscious state
            if (checkType === "stun" || checkType === "slam") {
              const currentHp = saveActor.system?.attributes?.health?.value ?? 0;
              if (currentHp <= 0) {
                if (game.settings.get("msh-faserip", "debugMode")) {
                  console.log(`FASERIP | Skipping ${checkType} auto-save - target at 0 HP, death save handles state`);
                }
                continue;
              }
            }

            // Only auto-run on a client that can control this defender
            const canControlDefender = saveActor?.isOwner || game.user.isGM;
            if (!canControlDefender) {
              if (game.settings.get("msh-faserip", "debugMode")) {
                console.log("FASERIP | Auto-save skipping for defender I don't own", {
                  msgId: message.id,
                  user: game.user.name,
                  defender: saveActor.name
                });
              }
              continue;
            }

            // De-duplicate: one save per defender per check type per message
            const defUuid = saveActor.uuid || saveActor.id || saveActor.name;
            const key = `${checkType}:${defUuid}`;
            if (autoSaveDefenderKeys.has(key)) {
              if (game.settings.get("msh-faserip", "debugMode")) {
                console.log("FASERIP | Skipping duplicate auto-save", { key, defender: saveActor.name });
              }
              continue;
            }
            autoSaveDefenderKeys.add(key);

            // Only auto-run if the DEFENDER is in Full mode
            if (resolveCombatMode(saveActor) !== "full") continue;

            // Build prefill if present
            let prefill = {};
            try {
              if (el.dataset.prefill) {
                prefill = JSON.parse(el.dataset.prefill.replaceAll("&apos;","'"));
              }
            } catch (_){}

            // Ensure dmgThrough is available (slam/stun gates use it)
            if (prefill && typeof prefill.dmgThrough === "undefined") {
              prefill.dmgThrough = Number(el.dataset.dmg || 0);
            }
            if (!prefill.targetUuid && saveActor?.uuid) {
              prefill.targetUuid = saveActor.uuid;
              prefill.targetName = saveActor.name || "Target";
              prefill.targetEndRank = saveActor?.system?.abilities?.endurance?.rank || "Good";
            }

            // inside chips loop when roll: used
            await game.msh.actions.roll(checkType, {
              actor: saveActor,
              opts: { attackForm, prefill, autoApply: true }
            });
            firedAnyCheck = true;
          }

          // Nullify / Force Save auto-run if the message indicates a save is required
          const f = message?.flags?.[SCOPE] ?? {};
          if (forceBtns.length && f?.requiresSave) {
            // Prefer the flagged defender, else first selected target
            let saveActor = null;
            const defUuid = f?.defenderUuid || f?.targetUuid || "";
            if (defUuid) {
              try {
                const doc = await fromUuid(defUuid);
                saveActor = doc?.actor ?? doc ?? null;
              } catch (_){}
            }
            if (!saveActor && game.user?.targets?.size === 1) {
              saveActor = game.user.targets.first()?.actor ?? null;
            }
            if (saveActor && resolveCombatMode(saveActor) === "full") {
              await game.msh.actions.roll("save-nullify", {
                actor: saveActor,
                abilityName: f.saveAbility || "endurance",
                opts: {
                  intensity: f.saveIntensity || "power-rank",
                  fixedRank: f.saveFixedRank || "",
                  autoApply: true,
                  effectName: f.effectName,
                  failMessage: f.failMessage,
                  powerName: f.powerName
                }
              });
              firedAnyCheck = true;
            }
          }

          // Death Save auto-run
          /* if (deathBtns.length) {
            await game.msh.actions.roll("death-save", { actor: ownerActor });
            firedAnyCheck = true;
          } */
          
          // mark handled only if we actually ran something
          if (firedAnyCheck) {
            await safeSetFlag(message, SCOPE, "autoSaveHandled", true);
          }
        } // end if (mode === "full")
        } // end if (didSet)
      } // end !alreadyChecks
    } catch (err) {
      console.error("Auto-save rolling failed:", err);
    }
    // --- END auto-rolling saves ---
    } // end canDriveAutoSaves && !alreadyHandled block

    // Check if this message has an undo flag
    const undoData = message.flags?.[SCOPE]?.undo;

    if (undoData?.results?.length) {
      // This message has been applied - transform button
      const applyBtn = html.find('[data-action="apply-damage"]');
      if (applyBtn.length) {
        applyBtn.attr('data-action', 'undo-apply');
        applyBtn.text('Undo');
        applyBtn.attr('title', 'Revert these HP changes');
        applyBtn.prop('disabled', false);
      }
    }

    // 1) Stun/Slam/Kill/Escape chips
    html.on("click", "a.faserip-chip[data-check]", async (ev) => {
        // Respect disabled state
        const el = ev.currentTarget;
        if (el.getAttribute?.("aria-disabled") === "true" || el.dataset.autoDisabled === "1") {
          ev.preventDefault();
          return;
        }

      ev.preventDefault();
      //const el = ev.currentTarget;

      const checkType    = el.dataset.check;                // "stun" | "slam" | "kill" | "escape"
      const attackForm   = el.dataset.attackForm || "blunt";
      const dmgThrough   = Number(el.dataset.dmg || 0);
      if (dmgThrough <= 0 && checkType !== "escape") {
        ui.notifications.info("No penetrating damage; effect not applicable.");
        return;
      }

      const attackerUuid = el.dataset.attackerUuid || message.speaker?.actor;

      // Escape-specific data
      const defenderUuid = el.dataset.defenderUuid;
      const defenderName = el.dataset.defenderName;
      const defenderRank = el.dataset.defenderRank;

      // Handle escape checks separately
      if (checkType === "escape") {
        await handleEscapeCheck({ defenderUuid, defenderName, defenderRank });
        return;
      }

      // Resolve an owner actor for dialog/message context
      let ownerActor = null;
      try {
        if (attackerUuid) {
          const doc = await fromUuid(attackerUuid);
          ownerActor = doc?.actor ?? doc ?? null;
        }
      } catch (_) {}
      ownerActor = ownerActor ?? game.actors?.get(message.speaker?.actor) ?? game.user?.character ?? null;

      // Smart auto-population from targeted tokens
      let prefill = { dmgThrough, attackForm };
      const targets = game.user.targets;
      
      if (targets.size === 1) {
        const targetToken = targets.first();
        const targetActor = targetToken.actor;
        
        if (targetActor) {
          prefill.targetName = targetToken.name;
          prefill.targetEndRank = targetActor.system?.abilities?.endurance?.rank || "Good";
          prefill.targetUuid = targetActor.uuid;
          
          console.log(`FASERIP | Auto-populated target: ${prefill.targetName} (Endurance: ${prefill.targetEndRank})`);
        }
      } else if (targets.size > 1) {
        ui.notifications.warn("Multiple tokens targeted. Please select only one target for this check.");
      }

      const SCOPE = game.system?.id || "msh-faserip";
      const already =
        message.getFlag(SCOPE, "autoChecksRun") ||
        message.getFlag(SCOPE, "autoApplied"); // if you use this elsewhere
      if (already) return; // Full Auto already resolved saves/effects

      console.debug("FASERIP chip click ->", { checkType, attackForm, dmgThrough, ownerActor: ownerActor?.name, prefill });

      await ActionDispatcher.roll(checkType, {
        actor: ownerActor,
        opts: {
          attackForm,
          prefill
        }
      });
    });

    // 2) Breaking FEAT chip
    html.on("click", '[data-action="breaking-feat"]', async (ev) => {
      ev.preventDefault();
      const btn = ev.currentTarget;
      const weaponMat = btn.dataset.weaponMat || "Excellent";
      const targetMat = btn.dataset.targetMat || "";
      const actorUuid = btn.dataset.actorUuid;
      
      console.log("[FASERIP] Breaking FEAT button clicked:", {
        weaponMat,
        targetMat,
        actorUuid,
        allDataset: { ...btn.dataset }
      });

      let actor = null;
      try {
        if (actorUuid) {
          const doc = await fromUuid(actorUuid);
          actor = doc?.actor ?? doc ?? null;
        }
      } catch (_) {}

      openBreakingFeatDialog({ weaponMatRank: weaponMat, targetMatRank: targetMat, actor });
    });

    // 3) Grabbing Break Check chip
    html.on('click', '[data-action="grabbing-break"], [data-action="grabbing-break-check"]', async (ev) => {
      ev.preventDefault();
      const el = ev.currentTarget;
      try {
        const actorUuid = el.dataset.actorUuid;
        const actor = actorUuid ? await fromUuid(actorUuid) : null;
        const itemMaterial = el.dataset.itemMaterial || "Excellent";
        const itemName = el.dataset.itemName || "Item";
        const { openGrabbingBreakDialog } = await import("./grabbing-break.js");
        openGrabbingBreakDialog({ actor, itemMaterial, itemName });
      } catch (e) {
        console.error("[FASERIP] Grabbing Break handler failed:", e);
        ui.notifications.error("Could not open Grabbing Break dialog. See console for details.");
      }
    });

    // 4) Collision Damage Calculator chip
    html.on("click", '[data-action="calculate-collision"]', async (ev) => {
      ev.preventDefault();
      ev.stopImmediatePropagation();
      const btn = ev.currentTarget;
      
      const targetName = btn.dataset.targetName || "Target";
      const targetUuid = btn.dataset.targetUuid || "";
      const targetEndurance = btn.dataset.targetEndurance || "Good";
      const slamDistance = Number(btn.dataset.slamDistance || 1);

      openCollisionDamageDialog({ 
        targetName, 
        targetUuid,
        targetEndurance, 
        slamDistance 
      });
    });

    // Reload weapon from out-of-ammo chat card
    html.on("click", ".faserip-reload-weapon", async (ev) => {
      ev.preventDefault();
      const btn = ev.currentTarget;
      const actorId  = btn.dataset.actorId;
      const itemId   = btn.dataset.itemId;
      const tokenId  = btn.dataset.tokenId;

      // Resolve actor: world actor first, then synthetic token actor
      let actor = game.actors?.get(actorId);
      if (!actor && tokenId) {
        actor = canvas.tokens?.get(tokenId)?.actor;
      }
      if (!actor) {
        ui.notifications.warn("Could not find actor to reload.");
        return;
      }

      const item = actor.items?.get(itemId);
      if (!item) { ui.notifications.warn("Could not find weapon to reload."); return; }

      const fullShots = item.system.shots || 0;
      await item.update({ "system.shotsRemaining": fullShots });
      btn.textContent = `✓ ${item.name} reloaded (${fullShots})`;
      btn.disabled = true;
      btn.style.background = "#2e7d32";
    });

    // 4b) Slam Collision button (from slam check results)
    html.on("click", '.calculate-slam-collision', async (ev) => {
      ev.preventDefault();
      ev.stopImmediatePropagation();
      const btn = ev.currentTarget;
      
      const targetUuid = btn.dataset.target || "";
      const slamDistance = Number(btn.dataset.distance || 1);
      
      // Try to get target name from UUID
      let targetName = "Target";
      if (targetUuid) {
        try {
          const resolved = await fromUuid(targetUuid);
          targetName = resolved?.name || resolved?.actor?.name || "Target";
        } catch (_) {}
      }

      openCollisionDamageDialog({ 
        targetName, 
        targetUuid,
        targetEndurance: "Good",  // Will be auto-populated from UUID
        slamDistance 
      });
    });

    // 5b) Apply Collision Damage button (applies directly to UUID, not targeted tokens)
    html.on("click", '[data-action="apply-collision-damage"]', async (ev) => {
      ev.preventDefault();
      ev.stopImmediatePropagation();
      const btn = ev.currentTarget;
      btn.disabled = true;

      try {
        const damage = Number(btn.dataset.damage || 0);
        const targetUuid = btn.dataset.targetUuid;

        if (!targetUuid || !damage) {
          ui.notifications.warn("Missing target or damage for collision");
          btn.disabled = false;
          return;
        }

        // Note: applyDamageToActorUuid(damage, actorUuid, options)
        await applyDamageToActorUuid(damage, targetUuid);
        
        btn.textContent = "Applied";
        btn.style.background = "#c8e6c9";
        btn.style.cursor = "default";
      } catch (err) {
        console.error("[FASERIP ERROR] Apply Collision Damage failed:", err);
        ui.notifications.error("Failed to apply collision damage");
        btn.disabled = false;
      }
    });

    // 5) Apply Damage button
    html.on("click", '[data-action="apply-damage"]', async (ev) => {
      ev.preventDefault();
      const btn = ev.currentTarget;
      btn.disabled = true;

      try {
        // 1) Read inputs from the button/card
        const damage          = Number(btn.dataset.damage || 0);
        const attackerUuid    = btn.dataset.attackerUuid || null;
        const bypassArmor     = btn.dataset.bypassArmor === "true";
        const damageType      = (btn.dataset.damageType || "physical-blunt").toLowerCase();
        const attackForm      = (btn.dataset.attackForm || "blunt").toLowerCase();
        const armorPiercing   = Number(btn.dataset.armorPiercing || 0) || 0;
        const armorPiercingCS = Number(btn.dataset.armorPiercingCs || 0) || 0; // note the 'Cs' in dataset
        const apMode          = btn.dataset.apMode || "value";
        const bypassForceField = btn.dataset.bypassForceField === "true";
        const wasKillResult   = btn.dataset.isKill === "true";

        // 2) Apply via rules and CAPTURE RETURNED RESULTS (one entry per target)
        const results = await applyDamageToTargets({
          damage: damage,
          attackerUuid,
          damageType,
          attackForm,
          armorPiercing,
          armorPiercingCS,
          apMode,
          wasKillResult,
          showNotification: true,
          bypassArmor,
          bypassForceField
        }) ?? [];

        debugLog("Chat Apply results", results);

        // 3) Persist undo info on the *correct* chat message
        const $msgEl = $(btn).closest("li.chat-message, .message, .chat-card, .message-content");
        const messageId =
          $msgEl.attr("data-message-id") ||
          $msgEl.data("messageId") ||
          $msgEl.closest("li.chat-message").attr("data-message-id");

        const msg   = messageId ? game.messages.get(messageId) : null;
        const SCOPE = game.system?.id || "msh-faserip";

        if (!msg) {
          console.warn("Undo flag: could not resolve ChatMessage from element; skipping flag write.");
        } else {
          await msg.setFlag(SCOPE, "undo", {
            ts: Date.now(),
            results: (results || []).map(r => ({
              actorUuid: r.actorUuid ?? r.targetActorUuid ?? r.targetUuid ?? null,
              tokenUuid: r.tokenUuid ?? null,
              hpBefore:  Number(r.hpBefore  ?? r.currentHealth ?? 0),
              hpAfter:   Number(r.hpAfter   ?? r.newHealth    ?? 0)
            }))
          });
        }

        // 4) Flip button into Undo state
        btn.dataset.action = "undo-apply";
        btn.textContent    = "Undo";
        btn.title          = "Revert these HP changes";
        btn.disabled       = false;

      } catch (err) {
        console.error("Apply Damage error:", err);
        ui.notifications?.error?.("Apply failed — see console for details.");
        btn.disabled = false;
      }
    });

    // Anchor: Undo handler (robust)
    html.on("click", "[data-action='undo-apply']", async (ev) => {
      ev.preventDefault();
      const btn = ev.currentTarget;
      btn.disabled = true;

      try {
        // Resolve the originating ChatMessage (same robust lookup used in Apply)
        const $msgEl = $(btn).closest("li.chat-message, .message, .chat-card, .message-content");
        const messageId =
          $msgEl.attr("data-message-id") ||
          $msgEl.data("messageId") ||
          $msgEl.closest("li.chat-message").attr("data-message-id");

        const msg   = messageId ? game.messages.get(messageId) : null;
        const SCOPE = game.system?.id || "msh-faserip";
        const data  = msg?.flags?.[SCOPE]?.undo;

        if (!msg || !data?.results?.length) {
          ui.notifications?.warn?.("Nothing to undo for this message.");
          btn.disabled = false;
          return;
        }

        // Health path helper (supports old/new schemas)
        const healthPath = (actor) =>
          (actor?.system?.attributes?.health?.value !== undefined)
            ? "system.attributes.health.value"
            : "system.health.value";

        for (const r of data.results) {
          const uuid = r.actorUuid || r.tokenUuid;
          if (!uuid) continue;

          // Resolve Actor or TokenDocument
          const doc   = await fromUuid(uuid);
          const actor = doc?.actor ?? doc;
          if (!actor) continue;

          const cur  = Number(actor?.system?.attributes?.health?.value ?? actor?.system?.health?.value ?? 0);
          const prev = Number(r.hpBefore ?? cur);
          const update = { [healthPath(actor)]: Math.max(0, prev) };

          // Try local update; fall back to GM bridge
          if (game.user.isGM || actor.isOwner) {
            await actor.update(update);
          } else if (game.msh?.socket?.executeAsGM) {
            // MODERN API (preferred)
            await game.msh.socket.executeAsGM("updateActor", {
              targetActorUuid: actor.uuid,
              updateData: update
            });
          } else if (game.msh?.runAsGM) {
            // LEGACY API (fallback)
            await game.msh.runAsGM({
              operation: "update",          // ← FIXED: was "updateActor"
              targetActorUuid: actor.uuid,
              args: [update]                // ← FIXED: was "data: update"
            });
          } else {
            ui.notifications?.warn?.(`Cannot undo for ${actor.name}: insufficient permission.`);
          }

          debugLog("Undo applied", { actor: actor.name, from: cur, to: prev });
        }

        // Lock the button after success
        btn.textContent = "Undone";
        btn.title       = "Already undone";
        btn.disabled    = true;

      } catch (err) {
        console.error("Undo error:", err);
        ui.notifications?.error?.("Undo failed — see console for details.");
        btn.disabled = false;
      }
    });

    // Hold Damage handler (Full Hold - grappling red result)
    html.on("click", '[data-action="hold-damage"]', async (ev) => {
      ev.preventDefault();
      const btn = ev.currentTarget;
      
      const attackerUuid = btn.dataset.attackerUuid;
      const maxDamage = Number(btn.dataset.maxDamage || 0);
      const damageRank = btn.dataset.damageRank || "Strength";
      const targetUuid = btn.dataset.targetUuid || "";
      const targetName = btn.dataset.targetName || "Target";
      
      // Get target actor for armor display
      let targetActor = null;
      let targetArmor = 0;
      let targetArmorSource = "";
      
      if (targetUuid) {
        try {
          const tDoc = await fromUuid(targetUuid);
          targetActor = tDoc?.actor ?? (tDoc?.documentName === "Actor" ? tDoc : null);
          if (targetActor) {
            const armorInfo = getBodyArmorValues(targetActor, "physical-blunt");
            targetArmor = armorInfo?.applicable ?? 0;
            targetArmorSource = armorInfo?.source ?? "";
          }
        } catch (_e) { /* ignore */ }
      }
      
      // Show dialog to choose damage amount
      const dialogHtml = `
        <div style="padding:4px 0;">
          <div style="margin-bottom:8px;">
            <strong>Deal Hold Damage</strong>
            <div style="color:#666;font-size:.9em;">Full Hold allows damage up to ${damageRank} (${maxDamage})</div>
          </div>
          
          <div style="margin-bottom:8px;">
            <label style="display:block;margin-bottom:4px;">Damage to inflict:</label>
            <input type="range" name="damage" min="0" max="${maxDamage}" value="${maxDamage}" style="width:100%;" id="hold-dmg-slider">
            <div style="display:flex;justify-content:space-between;font-size:.85em;color:#666;">
              <span>0</span>
              <span id="hold-dmg-display" style="font-weight:bold;color:#d32f2f;">${maxDamage}</span>
              <span>${maxDamage}</span>
            </div>
          </div>
          
          ${targetActor ? `
          <div style="padding:6px;background:#f5f5f5;border:1px solid #ddd;border-radius:3px;margin-bottom:8px;">
            <div><strong>${targetName}</strong></div>
            <div style="font-size:.9em;">Body Armor: ${targetArmor}${targetArmorSource ? ` (${targetArmorSource})` : ''}</div>
            <div style="font-size:.9em;color:#666;" id="hold-dmg-after">After armor: <strong>${Math.max(0, maxDamage - targetArmor)}</strong></div>
          </div>
          ` : `
          <div style="padding:6px;background:#fff3e0;border:1px solid #ff9800;border-radius:3px;margin-bottom:8px;font-size:.9em;">
            Target the held token to apply damage automatically, or apply manually.
          </div>
          `}
        </div>
      `;
      
      new Dialog({
        title: "Deal Hold Damage",
        content: dialogHtml,
        buttons: {
          apply: {
            icon: '<i class="fas fa-fist-raised"></i>',
            label: "Deal Damage",
            callback: async (html) => {
              const damage = Number(html.find('[name="damage"]').val() || 0);
              if (damage <= 0) {
                ui.notifications.info("No damage dealt.");
                return;
              }
              
              // Apply damage to target
              if (targetActor) {
                const results = await applyDamageToTargets({
                  damage: damage,
                  attackerUuid: attackerUuid,
                  damageType: "physical-blunt",
                  attackForm: "grappling",
                  showNotification: true,
                  bypassArmor: false
                });
                
                // Update button to show damage was applied
                btn.textContent = `Dealt ${damage}`;
                btn.disabled = true;
                btn.style.opacity = "0.6";
              } else {
                ui.notifications.info(`Deal ${damage} damage to held target (subject to Body Armor).`);
                btn.textContent = `${damage} dmg`;
                btn.disabled = true;
                btn.style.opacity = "0.6";
              }
            }
          },
          cancel: {
            icon: '<i class="fas fa-times"></i>',
            label: "Cancel"
          }
        },
        default: "apply",
        render: (html) => {
          // Update display as slider moves
          const slider = html.find('#hold-dmg-slider');
          const display = html.find('#hold-dmg-display');
          const afterDisplay = html.find('#hold-dmg-after');
          
          slider.on('input', function() {
            const val = Number(this.value);
            display.text(val);
            if (afterDisplay.length) {
              const afterArmor = Math.max(0, val - targetArmor);
              afterDisplay.html(`After armor: <strong>${afterArmor}</strong>`);
            }
          });
        }
      }).render(true);
    });

    // Grapple Back handler (Reverse - red escape result)
    html.on("click", '[data-action="grapple-back"]', async (ev) => {
      ev.preventDefault();
      const btn = ev.currentTarget;
      
      const attackerUuid = btn.dataset.attackerUuid;
      const targetUuid = btn.dataset.targetUuid || "";
      const targetName = btn.dataset.targetName || "Opponent";
      
      // Get the escaping actor (who will now be grappling)
      let grapplingActor = null;
      if (attackerUuid) {
        try {
          const doc = await fromUuid(attackerUuid);
          grapplingActor = doc?.actor ?? (doc?.documentName === "Actor" ? doc : null);
        } catch (_e) { /* ignore */ }
      }
      
      // Fall back to selected token or user's character
      if (!grapplingActor) {
        const controlled = canvas.tokens?.controlled?.[0];
        if (controlled?.actor) {
          grapplingActor = controlled.actor;
        }
      }
      if (!grapplingActor) {
        grapplingActor = game.user?.character;
      }
      
      if (!grapplingActor) {
        ui.notifications.warn("Select your token to attempt Grapple Back.");
        return;
      }
      
      // Get target actor's strength for prefill
      let targetStrength = "";
      if (targetUuid) {
        try {
          const tDoc = await fromUuid(targetUuid);
          const tActor = tDoc?.actor ?? (tDoc?.documentName === "Actor" ? tDoc : null);
          if (tActor) {
            targetStrength = tActor.system?.abilities?.strength?.rank || "";
          }
        } catch (_e) { /* ignore */ }
      }
      
      // Open grappling dialog with target prefilled
      await ActionDispatcher.roll("grappling", {
        actor: grapplingActor,
        opts: {
          prefill: {
            targetName: targetName,
            targetStrength: targetStrength,
            targetUuid: targetUuid
          }
        }
      });
      
      // Disable button after use
      btn.textContent = "Grappling...";
      btn.disabled = true;
      btn.style.opacity = "0.6";
    });

    // 6) Force Save (Nullification / RAW: Endurance vs Power Rank)
    html.on("click", '[data-action="force-save"], [data-action="force-save-nullify"]', async (ev) => {
      // Respect disabled state
      const el = ev.currentTarget;
      if (el.getAttribute?.("aria-disabled") === "true" || el.dataset.autoDisabled === "1") {
        ev.preventDefault();
        return;
      }

      ev.preventDefault();
      const btn = ev.currentTarget;
      const $msg = $(btn).closest(".message");
      const msg = game.messages.get($msg.data("messageId"));
      const f = msg?.flags?.["msh-faserip"] || {};
      if (!f.requiresSave) return;

      const ability    = btn.dataset.saveAbility || f.saveAbility || "endurance";
      const intensity  = f.saveIntensity || "power-rank"; // "power-rank" | "fixed-rank" | "none"
      const fixedRank  = f.saveFixedRank || "";
      const ignoreGate = (f.saveIgnoreGate !== false);

      // Attacker (for labels/origin)
      let ownerActor = null;
      try {
        if (f.attackerUuid) {
          const doc = await fromUuid(f.attackerUuid);
          ownerActor = doc?.actor ?? doc ?? null;
        }
      } catch (_) {}
      ownerActor = ownerActor ?? game.actors?.get(msg.speaker?.actor) ?? game.user?.character ?? null;

      // Prefill every currently targeted token (area handling — RAW affects all within range; we use selection)
      const targets = Array.from(game.user?.targets ?? []);
      const prefill = {};
      if (targets.length === 1) {
        const t = targets[0];
        prefill.targetName    = t.name;
        prefill.targetUuid    = t.actor?.uuid ?? "";
        prefill.targetEndRank = t.actor?.system?.abilities?.[ability]?.rank || "Good";
        prefill.dmgThrough    = 0;      // saves don't require penetrating damage
        prefill.attackForm    = "mental";
      }

      await ActionDispatcher.roll("save-nullify", {
        actor: ownerActor,
        abilityName: ability,
        opts: {
          prefill,
          ignoreDamageGate: ignoreGate,
          intensity,
          fixedRank,
          effectName: f.effectName,
          failMessage: f.failMessage,
          powerName: f.powerName
        }
      });

      // NOTE: Your CheckAction handles the actual FEAT + result. Make sure "save-nullify"
      // has labels/effects configured in action-config (fail => nullified).
    });

    // While active, nullifier cannot use other inborn powers (guarded in energy-action.js)
    // 7) Toggle Nullify Aura (maintain while in range)
    html.on("click", '[data-action="toggle-nullify-aura"]', async (ev) => {
      ev.preventDefault();
      const btn = ev.currentTarget;
      const $msg = $(btn).closest(".message");
      const msg = game.messages.get($msg.data("messageId"));
      const f = msg?.flags?.["msh-faserip"] || {};

      let actor = null;
      try {
        if (f.attackerUuid) {
          const doc = await fromUuid(f.attackerUuid);
          actor = doc?.actor ?? doc ?? null;
        }
      } catch (_) {}
      actor = actor ?? game.actors?.get(msg.speaker?.actor) ?? game.user?.character ?? null;
      if (!actor) return;

      // Use helpers from nullify.js
      try {
        if (isAuraMaintained(actor)) {
          await stopAura(actor);
          ui.notifications.info(`${actor.name} stops maintaining Nullification.`);
        } else {
          await startAura(actor, f.nullify?.powerItemUuid ?? null);
          ui.notifications.info(`${actor.name} is now maintaining Nullification (while in range).`);
        }
      } catch (e) {
        console.warn("Nullify aura toggle failed:", e);
        ui.notifications.error("Failed to toggle Nullify aura (see console).");
      }
    });

    // 8) Apply Defense Effect (dodging/evading/blocking/catching)
    html.on("click", '[data-action="apply-effect"]', async (ev) => {
      ev.preventDefault();
      const btn = ev.currentTarget;
      const $msg = $(btn).closest(".message");
      const msg = game.messages.get($msg.data("messageId"));
      
      // Get actor from message speaker
      let actor = null;
      try {
        if (msg.speaker?.actor) {
          actor = game.actors.get(msg.speaker.actor);
        }
      } catch (_) {}
      
      if (!actor) {
        ui.notifications.warn("Could not find actor for this defense action.");
        return;
      }
      
      // Read temp flags
      const defenseTemp = await actor.getFlag("msh-faserip", "defenseTemp") || {};
      
      // Determine which defense action this was and create appropriate effect
      let effectCreated = false;
      
      if (defenseTemp.dodging) {
        await createDodgingEffect(actor, defenseTemp.dodging);
        effectCreated = true;
      } else if (defenseTemp.evading) {
        await createEvadingEffect(actor, defenseTemp.evading);
        effectCreated = true;
      } else if (defenseTemp.blocking) {
        await createBlockingEffect(actor, defenseTemp.blocking);
        effectCreated = true;
      } else if (defenseTemp.catching) {
        await createCatchingEffect(actor, defenseTemp.catching);
        effectCreated = true;
      }
      
      if (!effectCreated) {
        ui.notifications.warn("No defense data found for this action.");
        return;
      }
      
      // Update button
      btn.style.opacity = "0.5";
      btn.style.pointerEvents = "none";
      btn.textContent = "✓ Effect Applied";
      
      ui.notifications.info(`Defense effect applied to ${actor.name}`);
    });

    // 9) Use Blocking Armor (separate button for blocking)
    html.on("click", '[data-action="use-armor"]', async (ev) => {
      ev.preventDefault();
      const btn = ev.currentTarget;
      const $msg = $(btn).closest(".message");
      const msg = game.messages.get($msg.data("messageId"));
      
      let actor = null;
      try {
        if (msg.speaker?.actor) {
          actor = game.actors.get(msg.speaker.actor);
        }
      } catch (_) {}
      
      if (!actor) {
        ui.notifications.warn("Could not find actor for blocking armor.");
        return;
      }
      
      const defenseTemp = await actor.getFlag("msh-faserip", "defenseTemp") || {};
      
      if (!defenseTemp.blocking) {
        ui.notifications.warn("No blocking data found.");
        return;
      }
      
      await createBlockingEffect(actor, defenseTemp.blocking);
      
      btn.style.opacity = "0.5";
      btn.style.pointerEvents = "none";
      btn.textContent = "✓ Armor Applied";
      
      ui.notifications.info(`Blocking armor applied to ${actor.name}`);
    });

    // 10) Death Save
    html.on("click", '[data-action="death-save"]', async (ev) => {
      // Respect disabled state
      const el = ev.currentTarget;
      if (el.getAttribute?.("aria-disabled") === "true" || el.dataset.autoDisabled === "1") {
        ev.preventDefault();
        return;
      }

      ev.preventDefault();
      const btn = ev.currentTarget;
      const actorUuid = btn.dataset.actorUuid;
      const attackForm = btn.dataset.attackForm || "";
      const fromZeroHealth = btn.dataset.fromZeroHealth !== "false"; // Default true
      
      try {
        const resolved = await fromUuid(actorUuid);
        const actor = resolved?.documentName === "Actor" 
          ? resolved 
          : (resolved?.documentName === "Token" ? resolved.actor : null);
        
        if (!actor) {
          ui.notifications.warn("Could not find actor for death save.");
          return;
        }
        
        await ActionDispatcher.roll("death-save", { 
          actor,
          opts: { attackForm, fromZeroHealth }
        });
      } catch (err) {
        console.error("Death save handler failed:", err);
        ui.notifications.error("Failed to open death save dialog.");
      }
    });

    // 11) Kill Save (Kill result from attack while still has HP - character stays conscious)
    html.on("click", '[data-action="kill-save"]', async (ev) => {
      // Respect disabled state
      const el = ev.currentTarget;
      if (el.getAttribute?.("aria-disabled") === "true" || el.dataset.autoDisabled === "1") {
        ev.preventDefault();
        return;
      }

      ev.preventDefault();
      const btn = ev.currentTarget;
      const actorUuid = btn.dataset.actorUuid;
      const attackForm = btn.dataset.attackForm || "";
      // Kill save from attack = NOT from zero health, character stays conscious if they fail
      const fromZeroHealth = false;
      
      try {
        const resolved = await fromUuid(actorUuid);
        const actor = resolved?.documentName === "Actor" 
          ? resolved 
          : (resolved?.documentName === "Token" ? resolved.actor : null);
        
        if (!actor) {
          ui.notifications.warn("Could not find actor for kill save.");
          return;
        }
        
        await ActionDispatcher.roll("death-save", { 
          actor,
          opts: { attackForm, fromZeroHealth }
        });
      } catch (err) {
        console.error("Kill save handler failed:", err);
        ui.notifications.error("Failed to open kill save dialog.");
      }
    });

  }); // End of single combined Hooks.on

  console.log("MSH FASERIP | Chat hooks installed (checks + breaking FEAT + grabbing break + collision damage + escape + apply damage)");
}

/**
 * Helper functions to create defense-related ActiveEffects
 */

/**
 * Create a Dodging effect
 */
async function createDodgingEffect(actor, data) {
  const { attackerPenaltyCS, selfPenaltyCS, notes } = data;
  
  // Remove any existing dodging effects first
  const existingDodge = actor.effects.find(e => e.flags?.["msh-faserip"]?.isDodging);
  if (existingDodge) await existingDodge.delete();
  
  const penaltyText = attackerPenaltyCS !== 0 
    ? `${attackerPenaltyCS}CS to attackers` 
    : "no penalty";
  
  const defenseBonus = Math.abs(attackerPenaltyCS);
  const effectData = {
    name: `Dodging (${penaltyText})`,
    icon: "icons/svg/windmill.svg",
    origin: actor.uuid,
    disabled: false,
    duration: {
      rounds: 1,
      startRound: game.combat?.round || 0
    },
    flags: {
      "msh-faserip": {
        isDodging: true,
        attackerPenaltyCS: attackerPenaltyCS,
        selfPenaltyCS: selfPenaltyCS,
        notes: notes
      }
    },
    changes: [
      // Half movement while dodging (ruler reads this multiplier)
      { key: "system.combatMods.movementMult", mode: 5, value: "0.5", priority: 20 },
      // -2CS on all own FEATs while dodging
      { key: "system.combatMods.selfPenaltyCS", mode: 2, value: "-2", priority: 20 },
      ...(defenseBonus > 0 ? [
        { key: "system.combatMods.defenseShift", mode: 2, value: String(defenseBonus), priority: 20 },
        { key: "system.combatMods.defenseShiftRanged", mode: 2, value: String(defenseBonus), priority: 20 }
      ] : [])
    ]
  };
  
  await actor.createEmbeddedDocuments('ActiveEffect', [effectData]);
}

/**
 * Create an Evading effect
 */
async function createEvadingEffect(actor, data) {
  const { target, evadeSuccessful, autoHit, nextRoundAttackBonusCS, note } = data;
  await Effects.applyEvade(actor, { 
    target, 
    evadeSuccessful: evadeSuccessful ?? true, 
    autoHit: autoHit ?? false,
    nextRoundAttackBonusCS, 
    note 
  });
}


/**
 * Create a Blocking effect
 */
async function createBlockingEffect(actor, data) {
  const { armorRank, armorValue } = data;
  await Effects.applyBlock(actor, { armorRank, armorValue });
}


/**
 * Create a Catching effect (mainly a reminder/note)
 */
async function createCatchingEffect(actor, data) {
  const { scenario, vsYou, note } = data;
  await Effects.applyCatch(actor, { scenario, vsYou, note });
}


export async function postAttackChatCard({
  actor, actionId, label, ability, roll, resultColor,
  baseDamage = 0, bonusDamage = 0, finalDamage = null,
  targets = [], notes = ""
}) {
  const dmg = finalDamage ?? (baseDamage + bonusDamage);
  const tNames = targets?.length ? targets.map(t => t.name).join(", ") : "—";
  const colorName = (resultColor||"").toUpperCase();

  const content = `
  <div class="faserip-chat-card" data-action="${actionId}">
    <div class="faserip-header"><b>${label}</b> — ${ability.toUpperCase()}</div>
    <div class="faserip-row"><b>Roll:</b> ${roll.total ?? roll} &nbsp; <b>Result:</b> ${colorName}</div>
    <div class="faserip-row"><b>Targets:</b> ${tNames}</div>
    <div class="faserip-row"><b>Damage:</b> ${dmg}</div>
    ${notes ? `<div class="faserip-notes">${notes}</div>` : ""}
    <div class="faserip-actions" style="margin-top:6px; display:flex; gap:6px; flex-wrap:wrap;">
      <a class="faserip-chip" data-action="apply-damage">Apply Damage</a>
      ${/YELLOW|RED/.test(colorName) ? `<a class="faserip-chip" data-action="resolve-stun-slam">Resolve Stun/Slam</a>` : ""}
    </div>
  </div>`;

  return ChatMessage.create({
    user: game.user.id,
    speaker: ChatMessage.getSpeaker({ actor }),
    content,
    type: CONST.CHAT_MESSAGE_TYPES.OTHER,
    flags: {
      "msh-faserip": { baseDamage, bonusDamage, finalDamage: dmg, targets: targets.map(t => t.id) }
    }
  });
}

export async function handleEscapeAttempt({ defenderUuid, defenderName, defenderRank }) {
  if (!defenderUuid) {
    ui.notifications.warn("No defender UUID provided for escape attempt.");
    return;
  }

  const defender = await fromUuid(defenderUuid);
  if (!defender) {
    ui.notifications.warn(`Cannot find defender: ${defenderName || "Unknown"}`);
    return;
  }

  const defenderStrength = defender.system?.abilities?.strength?.rank || defenderRank || "Typical";
  const defenderStrengthValue = defender.system?.abilities?.strength?.value || game.msh.getRankValue(defenderStrength) || 6;
  const actualDefenderName = defenderName || defender.name || "Target";

  const savedShift = await defender.getFlag("msh-faserip", "lastEscapeShift") ?? 0;
  const savedSpendKarma = false; // Always default to unchecked
  const savedRemember = await defender.getFlag("msh-faserip", "lastEscapeRemember") ?? true;
  const savedSkipDice = await defender.getFlag("msh-faserip", "lastEscapeSkipDice") ?? false;

  const dialogHtml = `
    <div style="line-height:1.4;">
      <div style="margin-bottom:8px;">
        <label style="display:inline-block;width:130px;">Action:</label>
        <strong>Escaping</strong>
      </div>
      <div style="margin-bottom:8px;">
        <label style="display:inline-block;width:130px;">Character:</label>
        <strong>${actualDefenderName}</strong>
      </div>
      <div style="margin-bottom:8px;">
        <label style="display:inline-block;width:130px;">Strength:</label>
        <input type="text" value="${defenderStrength}" style="width:160px;" readonly>
        <span style="margin-left:6px;">(${defenderStrengthValue})</span>
      </div>
      <div style="margin-bottom:8px;">
        <label style="display:inline-block;width:130px;">Column Shift:</label>
        <input type="number" name="shift" value="${Number(savedShift)}" style="width:60px;">
        <span style="color:#666;font-size:.9em;">(+ easier, - harder)</span>
      </div>
      ${generateKarmaControlsHTML(defender, savedSpendKarma)}
      <div style="margin-top:6px;">
        <label><input type="checkbox" name="remember" ${savedRemember ? 'checked' : ''}> Remember these settings</label>
      </div>
      <div style="margin-top:8px;">
        <label><input type="checkbox" name="skipDice" ${savedSkipDice ? 'checked' : ''}> Skip dice animation</label>
      </div>
      <div style="margin-top:12px;padding:8px;background:#f5f5f5;border:1px solid #ddd;border-radius:3px;">
        <div style="font-weight:bold;margin-bottom:4px;">Escape Results</div>
        <div style="font-size:.85em;color:#555;">
          <strong>Miss (White/Green):</strong> Still held; no other actions.<br>
          <strong>Escape (Yellow):</strong> Free; may move up to half speed; no other actions.<br>
          <strong>Reverse (Red):</strong> Free; move ½, Grapple attacker, or take another action at -2 CS.
        </div>
      </div>
    </div>
  `;

  new Dialog({
    title: `Escape Attempt: ${actualDefenderName}`,
    content: dialogHtml,
    buttons: {
      roll: {
        label: "Roll Escape",
        callback: async (html) => {
          const $ = (s) => html.find(s);
          const shift = Number($('[name="shift"]').val() || 0);
          const { spendKarma } = extractKarmaFromDialog(html);
          const remember = $(`[name="rememberSettings"]`).length ? !!$(`[name="rememberSettings"]`).is(':checked') : !!$(`[name="remember"]`).is(':checked');
          const skipDice = $(`[name="skipDiceRoll"]`).length ? !!$(`[name="skipDiceRoll"]`).is(':checked') : !!$(`[name="skipDice"]`).is(':checked');

          // Always save remember/skipDice preferences
          await defender.setFlag("msh-faserip", "lastEscapeRemember", remember);
          await defender.setFlag("msh-faserip", "lastEscapeSkipDice", skipDice);

          // Persist shift if requested (karma checkbox never persisted)
          if (remember) {
            await defender.setFlag("msh-faserip", "lastEscapeShift", shift);
          }

          const effectiveRank = shiftRank(defenderStrength, shift);
          const roll = await (new Roll("1d100")).evaluate();
          
          if (!skipDice) {
            await roll.toMessage({
              speaker: ChatMessage.getSpeaker({ actor: defender }),
              flavor: `${actualDefenderName} attempts to Escape`,
              rollMode: game.settings.get("core", "rollMode")
            });
          }

          const { cappedTotal, totalKarmaUsed } = 
            await rollWithKarmaAndHistory(defender, "Escaping", 0, roll, { spendKarma, rank: effectiveRank });

          const color = game.msh.rollUniversalTable(effectiveRank, cappedTotal);
          const colorLower = String(color || "").toLowerCase();
          const effects = effectsFor("escaping");
          const effect = effects[colorLower] || "Miss";
          const grid = buildResultGrid("escaping", colorLower, effects);
          const { bg, fg } = bannerColors(colorLower);

          const effectBlocks = {
            miss: `<div style="padding:6px 10px;margin:6px 10px;background:#ffebee;border:1px solid #ef5350;border-radius:3px;">
              <div style="font-weight:bold;color:#c62828;">Miss</div>
              <div style="font-size:.9em;">Still held this turn; no other actions.</div>
            </div>`,
            escape: `<div style="padding:6px 10px;margin:6px 10px;background:#e3f2fd;border:1px solid #2196F3;border-radius:3px;">
              <div style="font-weight:bold;color:#0d47a1;">Escape</div>
              <div style="font-size:.9em;">Free of hold; may move up to half speed (no other actions).</div>
            </div>`,
            reverse: `<div style="padding:6px 10px;margin:6px 10px;background:#e8f5e9;border:1px solid #66bb6a;border-radius:3px;">
              <div style="font-weight:bold;color:#2e7d32;">Reverse</div>
              <div style="font-size:.9em;">Free; may move ½, Grapple attacker, or take another action at -2 CS.</div>
            </div>`
          };

          const effectBlock = effectBlocks[effect.toLowerCase()] || "";

          const cardHtml = `
            <div style="background:#f5f5f0;border:1px solid #c0c0c0;border-radius:3px;margin-bottom:5px;">
              <div style="padding:5px 10px;border-bottom:1px solid #c0c0c0;font-size:1.1em;color:#8b0000;">
                <strong>${actualDefenderName} — Escape Attempt</strong>
              </div>
              <div style="padding:5px 10px;font-size:.9em;">
                <div>Strength: ${defenderStrength} (${defenderStrengthValue})${shift ? ` — Shift ${shift} → ${effectiveRank}` : ""}</div>
                <div>Roll: ${roll.total}${totalKarmaUsed ? ` + Karma: ${totalKarmaUsed}` : ``} = ${cappedTotal}</div>
              </div>
              ${grid}
              <div style="text-align:center;padding:8px;margin:5px;font-weight:bold;font-size:1.05em;border-radius:3px;background:${bg};color:${fg};">
                RESULT: ${String(color).toUpperCase()} — ${String(effect).toUpperCase()}
              </div>
              ${effectBlock}
            </div>
          `;

          await ChatMessage.create({ 
            speaker: ChatMessage.getSpeaker({ actor: defender }), 
            content: cardHtml 
          });

          // Remove hold effects on successful escape (yellow=Escape or red=Reverse only)
          if (colorLower === "yellow" || colorLower === "red") {
            console.log(`[FASERIP] Escape successful (${colorLower}), removing hold effects from ${actualDefenderName}`);
            console.log(`[FASERIP] Checking ${defender.effects?.size || 0} effects`);
            
            const holdEffects = [];
            for (const e of defender.effects || []) {
              if (e.disabled) continue;
              
              // Check statuses (handle both Set and Array)
              const hasGrappledStatus = e.statuses?.has?.("grappled") || Array.from(e.statuses || []).includes("grappled");
              const hasHeldStatus = e.statuses?.has?.("held") || Array.from(e.statuses || []).includes("held");
              
              const flags = e.flags?.["msh-faserip"] || {};
              const hasGrappledFlag = flags.effectType === "grappled" || flags.status?.isGrappled;
              const hasHeldFlag = flags.effectType === "held" || flags.status?.isHeld;
              
              const name = (e.name || "").toLowerCase();
              const hasGrappledName = name.includes("grappled") || name.includes("partial hold");
              const hasHeldName = name.includes("held") || name.includes("full hold");
              
              const isHoldEffect = hasGrappledStatus || hasHeldStatus || hasGrappledFlag || hasHeldFlag || hasGrappledName || hasHeldName;
              
              console.log(`[FASERIP] Effect "${e.name}": statuses=${Array.from(e.statuses || [])}, flagType=${flags.effectType}, isHold=${isHoldEffect}`);
              
              if (isHoldEffect) holdEffects.push(e);
            }
            
            console.log(`[FASERIP] Found ${holdEffects.length} hold effects to remove`);
            
            for (const eff of holdEffects) {
              try {
                await eff.delete();
                console.log(`[FASERIP] Removed hold effect: ${eff.name}`);
              } catch (err) {
                console.warn(`[FASERIP WARN] Failed to remove effect ${eff.name}:`, err);
              }
            }
          } else {
            console.log(`[FASERIP] Escape failed (${colorLower}), hold effects remain`);
          }
        }
      },
      cancel: { label: "Cancel" }
    },
    default: "roll",
    render: (html) => { setupKarmaControlHandlers(html); }
  }).render(true);
}