// scripts/modules/actions/mental-power-action.js
import { BaseAction } from "./base-action.js";
import { resolveCombatMode } from "./action-dispatcher.js";
import { buildActionsBox } from "./action-utils.js";

/**
 * Mental Power Action - for powers that skip to-hit roll and go straight to saves
 * Examples: Psionic Attack, Mind Control, Emotion Control, Mental Probe
 */
export class MentalPowerAction extends BaseAction {
  constructor(config) {
    const actor = config.actor;
    const opts = config.opts || {};
    const itemId = opts.itemId;
    
    super({ actor, abilityName: "psyche", opts });
    
    this.item = itemId ? actor.items.get(itemId) : null;
    this.actionType = "mental-power";
  }

  async execute() {
    const actor = this.actor;
    const item = this.item;

    if (!item) {
      ui.notifications.error("No mental power selected");
      return;
    }

    const powerName = item.name;
    const powerRank = item.system.rank || "Typical";
    const powerValue = item.system.value || 6;
    const range = item.system.range || "rank";
    const calculatedRange = item.system.calculatedRange || this._getRangeByRank(powerRank);
    
    // Determine save ability from power system or default to Psyche
    const saveAbility = item.system.save?.ability || this._getDefaultSaveAbility(item);
    const saveIntensity = item.system.save?.intensity || "power-rank";
    const saveFixedRank = item.system.save?.fixedRank || powerRank;

    // Check if power requires a save
    const requiresSave = item.system.requiresSave !== false; // Default true for mental powers

    // Get targets
    const targets = Array.from(game.user.targets);
    
    if (targets.length === 0) {
      ui.notifications.warn("No target selected for mental power");
      return;
    }

    if (targets.length > 1) {
      ui.notifications.warn("Mental powers affect one target at a time. Using first target.");
    }

    const target = targets[0];
    const targetActor = target.actor;
    const targetName = targetActor?.name || "Unknown";

    // Determine combat mode
    const combatMode = resolveCombatMode(targetActor);
    const isManualMode = this.opts?.mode === "manual" || combatMode === "manual";
    const isFullAuto = combatMode === "full";

    // Build dialog
    const dialogHtml = `
      <div style="margin-bottom:8px;">
        <strong>Power:</strong> ${powerName}
      </div>
      <div style="margin-bottom:8px;">
        <strong>Rank:</strong> ${powerRank} (${powerValue})
      </div>
      <div style="margin-bottom:8px;">
        <strong>Range:</strong> ${calculatedRange}
      </div>
      <div style="margin-bottom:12px;">
        <strong>Target:</strong> ${targetName}
      </div>
      
      <div style="padding:8px;background:#fff3cd;border:1px solid #ffc107;border-radius:3px;margin-bottom:12px;">
        <div style="font-weight:bold;margin-bottom:4px;">Mental Power - No Attack Roll</div>
        <div style="font-size:0.9em;">Target must make a <strong>${saveAbility.toUpperCase()}</strong> save vs <strong>${powerRank}</strong> intensity</div>
        ${isFullAuto ? '<div style="font-size:0.85em;margin-top:4px;font-style:italic;">Save will auto-trigger in Full Auto mode</div>' : ''}
      </div>

      <div style="margin-bottom:8px;">
        <label>
          <input type="checkbox" name="skipAnimation" ${this.opts.skipDice ? "checked" : ""}>
          Skip animation
        </label>
      </div>
    `;

    const choice = await new Promise((resolve) => {
      new Dialog({
        title: `${powerName} - Mental Power`,
        content: dialogHtml,
        buttons: {
          use: {
            icon: '<i class="fas fa-brain"></i>',
            label: "Use Power",
            callback: (html) => {
              resolve({
                skipAnimation: html.find('[name="skipAnimation"]').is(':checked')
              });
            }
          },
          cancel: {
            icon: '<i class="fas fa-times"></i>',
            label: "Cancel",
            callback: () => resolve(null)
          }
        },
        default: "use"
      }).render(true);
    });

    if (!choice) return;

    // Build action buttons
    const actionsHtml = buildActionsBox({
      showNullifySave: requiresSave,
      nullifyIntensityRank: powerRank,
      actorUuid: actor.uuid,
      targetUuid: target.document?.uuid || target.actor?.uuid,
      targetName: targetName,
      autoApply: false, // Mental powers don't apply damage
      autoSave: isFullAuto, // Hide save button in full auto
      attackForm: "mental"
    });

    // Create chat card
    const cardHtml = `
      <div style="background:#f5f5f0;border:1px solid #c0c0c0;border-radius:3px;margin-bottom:5px;">
        <div style="padding:5px 10px;border-bottom:1px solid #c0c0c0;font-size:1.1em;color:#0d47a1;">
          <strong>${actor.name} uses ${powerName}</strong>
          <br><span style="font-size:.85em;color:#555;">→ ${targetName}</span>
        </div>
        <div style="padding:5px 10px;font-size:.9em;">
          <div><strong>Power Rank:</strong> ${powerRank} (${powerValue})</div>
          <div><strong>Range:</strong> ${calculatedRange}</div>
          <div><strong>Type:</strong> Mental Power (no attack roll)</div>
        </div>
        <div style="text-align:center;padding:8px;margin:5px;font-weight:bold;font-size:1.1em;border-radius:3px;background:#9c27b0;color:#fff;">
          TARGET MUST SAVE VS ${powerRank.toUpperCase()}
        </div>
        <div style="padding:8px;margin:5px;background:#f3e5f5;border:1px solid #9c27b0;border-radius:3px;">
          <div style="font-size:0.9em;"><strong>Save Required:</strong> ${saveAbility.toUpperCase()} FEAT</div>
          <div style="font-size:0.9em;"><strong>Intensity:</strong> ${powerRank}</div>
          ${item.system.save?.onFail?.notes ? `<div style="font-size:0.85em;margin-top:4px;font-style:italic;">${item.system.save.onFail.notes}</div>` : ''}
        </div>
        ${actionsHtml}
      </div>
    `;

    // Build message flags for auto-save
    const msgFlags = {
      "msh-faserip": {
        actionId: "mental-power",
        powerName: powerName,
        powerRank: powerRank,
        powerValue: powerValue,
        requiresSave: requiresSave,
        saveAbility: saveAbility,
        saveIntensity: saveIntensity,
        saveFixedRank: saveFixedRank,
        targetUuid: target.document?.uuid || target.actor?.uuid,
        defenderUuid: target.document?.uuid || target.actor?.uuid,
        itemId: item.id,
        // Include save configuration from power
        saveConfig: item.system.save || {}
      }
    };

    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: cardHtml,
      flags: msgFlags
    });

    // Play mental power SFX if available
    if (game.msh?.playCombatSFX) {
      await game.msh.playCombatSFX("mental", powerName, "purple");
    }
  }

  /**
   * Determine default save ability based on power type
   */
  _getDefaultSaveAbility(item) {
    const type = (item.system.type || "").toLowerCase();
    const name = (item.name || "").toLowerCase();

    // Emotion-based powers use Intuition
    if (type.includes("emotion") || name.includes("emotion")) {
      return "intuition";
    }

    // Most mental powers use Psyche
    return "psyche";
  }

  /**
   * Get range by rank (same as in itemSheet.js)
   */
  _getRangeByRank(rank) {
    const rankRanges = {
      "Feeble": "Touch only",
      "Poor": "Touch only",
      "Typical": "1 area",
      "Good": "2 areas",
      "Excellent": "4 areas",
      "Remarkable": "6 areas",
      "Incredible": "8 areas",
      "Amazing": "10 areas",
      "Monstrous": "20 areas",
      "Unearthly": "40 areas",
      "Shift-X": "60 areas",
      "Shift-Y": "80 areas",
      "Shift-Z": "160 areas",
      "Class 1000": "400 areas",
      "Class 3000": "100 miles",
      "Class 5000": "10,000 miles",
      "Beyond": "1,000,000 miles"
    };
    return rankRanges[rank] || "Unknown";
  }
}