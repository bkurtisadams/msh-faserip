// scripts/vehicleSheet.js v2.0.0 - 2026-03-13
// v2.0.0: Stripped to stat card for compendium use — no tabs, no play-time fields
// v1.0.0: Initial vehicle item sheet

export class FaseripVehicleSheet extends ItemSheet {
  static get defaultOptions() {
    return mergeObject(super.defaultOptions, {
      classes: ["faserip", "sheet", "item", "vehicle"],
      width: 420,
      height: 480,
      template: "systems/msh-faserip/templates/vehicle-sheet.html"
    });
  }

  getData() {
    const context = super.getData();
    context.system = context.item.system;

    context.allRanks = [
      "Shift-0", "Feeble", "Poor", "Typical", "Good", "Excellent",
      "Remarkable", "Incredible", "Amazing", "Monstrous", "Unearthly",
      "Shift-X", "Shift-Y", "Shift-Z", "Class 1000", "Class 3000", "Class 5000", "Beyond"
    ];

    context.vehicleTypes = [
      "Road", "Off-Road", "Railed", "GEV", "Air", "Space", "Water", "Submersible"
    ];

    return context;
  }

  activateListeners(html) {
    super.activateListeners(html);

    html.find('.cancel-button').click(ev => {
      this.close();
    });
  }
}
